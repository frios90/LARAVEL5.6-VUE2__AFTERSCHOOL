@extends('web.layout')
@section('content')
    @include('web.main_equip_head')
    @include('web.main_about_mvh')
    @include('web.teachers')
@endsection