<footer class="footer" id="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-12">
                    <div class="widget clearfix">
                        <div class="widget-title">
                            <h3>Visita nuestras redes sociales</h3>
                        </div>
						<div class="footer-right">
							<ul class="footer-links-soi">
								<li><a href=""><i class="fa fa-facebook"></i></a></li>
								<li><a href=""><i class="fa fa-github"></i></a></li>
								<li><a href=""><i class="fa fa-twitter"></i></a></li>
								<li><a href=""><i class="fa fa-dribbble"></i></a></li>
								<li><a href=""><i class="fa fa-pinterest"></i></a></li>
							</ul><!-- end links -->
						</div>
                        <br>
                        <div >
                            <div class="widget clearfix">
                                <div class="widget-title">
                                    <h3>Enlaces</h3>
                                </div>
                                <ul class="footer-links">
                                    <li class="nav-item"><a class="" href="/">Virtual After School</a></li>
                                    <li class="nav-item"><a class="" href="/about">Nuestra Historia</a></li>
                                    <li class="nav-item"><a class="" href="/glifing">Glifing, Nuestro Pilar</a></li>
                                    <li class="nav-item"><a class="" href="/equip">Equipo Profesionales</a></li>
                                    <li class="nav-item"><a class="" href="/courses">Talleres</a></li>
                                    <li class="nav-item"><a class="" href="#footer">Contáctanos</a></li>
                                </ul>
                            </div>
                        </div>					
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-xs-12">
                    <div class="widget clearfix">
                        <div class="widget-title">
                            <h3>Contactanos</h3>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane active" id="Login">
                                <form id="contactanos" class="form-horizontal">
                                    <input type="hidden"id="token" value="{{ csrf_token() }}">  
                                    <div class="form-group">
                                        <label for="" class="">Ingrese su nombre</label>
                                        <div class="col-sm-12">
                                            <input class="form-control" id="name" placeholder="Ingrese su nombre" type="text">
                                            {!! $errors->first('name', '<span class="help-block">:message</span>') !!} 
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Ingrese su correo de contacto:</label>
                                        <div class="col-sm-12">
                                            <input class="form-control" id="correo"  placeholder="Ingrese su Correo" type="text" require="">
                                            {!! $errors->first('correo', '<span class="help-block">:message</span>') !!} 
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="">ingrese su teléfono de contacto:</label>
                                        <div class="col-sm-12">
                                            <input class="form-control" id="phone" placeholder="Ingrese su Teléfono" type="text" require="">
                                            {!! $errors->first('phone', '<span class="help-block">:message</span>') !!} 
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="">Dejenos su mensaje:</label>

                                        <div class="col-sm-12">
                                            <input class="form-control" id="message" placeholder="Ingrese su Mensaje" type="text" require="">
                                            {!! $errors->first('message', '<span class="help-block">:message</span>') !!} 
                                        </div>
                                    </div>
                                    <div class="progress">
                                        <div  class="progress-bar progress-bar-striped  progress-bar-animated active" role="progressbar" require="" style="width: 0%" aria-pressed="true" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>                                    
                                    <div class="row">
                                        <div class="col-sm-10">
                                            <input type="submit" class="btn btn-contact" value="Enviar"/>
                                        </div>
                                    </div>
                                </form>
                            </div>				
                        </div>
                    </div>
                </div>           
            </div>
        </div>
    </footer>
    <div class="copyrights">
        <div class="container">
            <div class="footer-distributed">
                <div class="footer-center">
                   Desarrollado por <a target="_blank" href="http://www.fejhu.cl" class="">Fejhu</a>
                </div>
            </div>
        </div>
    </div>
     <a href="#" id="scroll-to-top" class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>

<script src="js/web-all.js"></script>
<script src="js/web-bootstrap-touch-slider.js"></script>
<script src="js/web-custom.js"></script>
<script src="js/web-timeline.min.js"></script>
<script>
    timeline(document.querySelectorAll('.timeline'), {
        forceVerticalMode: 700,
        mode: 'horizontal',
        verticalStartPosition: 'left',
        visibleItems: 4
    });
</script>
<script type="text/javascript">
    $(document).ready(function() 
	{

        $('#contactanos').on('submit', function(event){
            event.preventDefault();
            var send = {
                "_token"   : $('#token').val(),
                "name"     : $('#name').val(),
                "phone"    : $('#phone').val(),
                "message"  : $('#message').val(),
                "correo"   : $('#correo').val()
            }
            var r = $.ajax({
                data: send,
                type: "POST",
                dataType: "json",
                url: "{{ route('/contact-mail') }}",
            }).done(function() {
                
            })
            $('.progress-bar').css('width', '0%');
            setTimeout(function(){$('.progress-bar').css('width', '10%'); },  1000);
            setTimeout(function(){$('.progress-bar').css('width', '20%'); },  2000);
            setTimeout(function(){$('.progress-bar').css('width', '30%'); },  3000);
            setTimeout(function(){$('.progress-bar').css('width', '40%'); },  4000);
            setTimeout(function(){$('.progress-bar').css('width', '50%'); },  5000);
            setTimeout(function(){$('.progress-bar').css('width', '60%'); },  6000);
            setTimeout(function(){$('.progress-bar').css('width', '70%'); },  7000);
            setTimeout(function(){$('.progress-bar').css('width', '80%'); },  8000);
            setTimeout(function(){$('.progress-bar').css('width', '90%'); },  9000);
            setTimeout(function(){$('.progress-bar').css('width', '100%');  },  10000);
            setTimeout(function(){alert('Tu mensaje ha sido enviado con éxito'); },  12000);
            setTimeout(function(){$('.progress-bar').css('width', '0%');
                            $('#name').val('')
                            $('#phone').val('')
                            $('#message').val('')
                            $('#correo').val('')
                                          },  12000);

           
               
        })
        $('#access-login').on('submit', function(event){
            $('#error-login').css('display', 'none')
            event.preventDefault();
            var send = {
                "_token"   : $('#token').val(),
                "email"    : $('#access-email').val(),
                "password" : $('#access-password').val(),               
            }
            var r = $.ajax({
                data: send,
                type: "POST",
                dataType: "json",
                url: "{{ route('/sing-in') }}",
                
                error: function (data) {
                    if (data.status == 200) {
                        window.location.replace(data.responseText);
                    } else {                      
                        $('#error-login').css('display', 'block')
                        $('#error-login').html('No pudieron validarse las credenciales. Reintente')
                    }
                   
                }
            })
        })
        $('#send-request-pass').on('click', function(event){
            $('#error-login').css('display', 'none')
            event.preventDefault()
            var send = {
                "_token"   : $('#token').val(),
                "email"    : $('#access-email').val(),
            }
            $.ajax({
                data: send,
                type: "POST",
                dataType: "json",
                url: "{{ route('/request-pass') }}",
                success: function (data) {
                    $('#success-request-pass').css('display', 'block')
                    $('#error-login').css('display', 'none')                   
                },
                error: function (data) {
                    $('#error-login').css('display', 'block')
                    $('#error-login').html('No hay una cuenta asociada a este correo.')
                }
            })
        })
   
    })
    </script>
<style>
<style>

form {
  /* Temp */
  padding:1rem;
  border:1px solid #ddd;
  border-radius:4px;
}

</style>