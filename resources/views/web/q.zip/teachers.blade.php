<div id="teachers" class="section wb section-bg-1">
        <div class="contenedor-profes">
            <div class="row">
				<div class="col-lg-1 col-md-1 col-12"></div>			
				<div class="equipo-foto col-lg-2 col-md-2 col-12">
					<div class="our-team">
						<div class="team-img">
							<img class="img-profes" src="images/jenny-maturana.jpg">
							<div class="social">
								<ul>
									<li><a target="_blank" href="https://www.facebook.com/Yoamopsp" class="fa fa-facebook"></a></li>
									<li><a target="_blank" href="https://www.linkedin.com/in/jenny-maturana-fern%C3%A1ndez-698baa37/" class="fa fa-linkedin"></a></li>
									<li><a target="_blank" href="https://www.instagram.com/yo_amo_psicopedagogia/" class="fa fa-instagram"></a></li>
								</ul>
							</div>
						</div>
						<div class="team-content">
							<h3 class="title title-name-teacher">Jenny Maturana</h3>
							<span class="post post-name-teacher">Psicopedagoga</span>
						</div>
					</div>
				</div>
				<div class="equipo-foto col-lg-2 col-md-2 col-12">
					<div class="our-team">
						<div class="team-img">
							<img class="img-profes" src="images/paula.jpg">
							<div class="social">
								<ul>
									<li><a target="_blank" href="https://www.linkedin.com/in/paulagarcialorca061980" class="fa fa-linkedin"></a></li>

								</ul>
							</div>
						</div>
						<div class="team-content">
							<h3 class="title title-name-teacher">Paula García</h3>
							<span class="post post-name-teacher">Psicopedagoga
							</span>
						</div>
					</div>
				</div>
				<div class="equipo-foto col-lg-2 col-md-2 col-12">
					<div class="our-team">
						<div class="team-img">
							<img class="img-profes" src="images/gabriel-vargas.jpg">
							<div class="social">
								<ul>								
								</ul>
							</div>
						</div>
						<div class="team-content">
							<h3 class="title title-name-teacher">Gabriel Vargas</h3>
							<span class="post post-name-teacher">Traductor Profesional Inglés Español Licenciado en Letras y Lenguas</span>
						</div>
					</div>
				</div>				
				<div class="equipo-foto col-lg-2 col-md-2 col-12">
					<div class="our-team">
						<div class="team-img">
							<img class="img-profes" src="images/danielagallardo2.jpg">
							<div class="social">
								<ul>
									<li><a target="_blank" href="https://www.linkedin.com/in/daniela-gallardo-valderrama-2573551a9" class="fa fa-linkedin"></a></li>
								</ul>
							</div>
						</div>
						<div class="team-content">
							<h3 class="title title-name-teacher">Daniela Gallardo</h3>
							<span class="post post-name-teacher">Filosofía, Terapias naturales y técnico en rehabilitación de adictos</span>
						</div>
					</div>
				</div>
						
            </div>
        </div>
    </div>