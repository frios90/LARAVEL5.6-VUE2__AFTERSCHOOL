<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tit-up">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Acceso al Portal</h4>
			</div>
			<div class="modal-body customer-box">				
				<div class="tab-content">
					<div class="tab-pane active" id="Login">
						<form id="access-login" class="form-horizontal">
						
                        @csrf    
                            <div class="form-group">
								<div class="col-sm-12">
									<label for="">Usuario / Correo</label>
									<input class="form-control" id="access-email" name="access-email" placeholder="Ingrese su nombre de usuario" type="email">
                                    <span id="error-login" style="display: none; color: red; font-size: 11px;">No pudieron validarse las credenciales. Reintente</span>
                                </div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<label for="">Contraseña</label>
									<input class="form-control" id="access-password" name="access-password" placeholder="Ingrese su contraseña" type="password">
                                    
                                </div>
							</div>
							<div class="row">
								<div class="col-sm-10">
                                    <input type="submit" class="btn btn-light btn-radius btn-brd grd1" value="Ingresar"/>
									<span id="send-request-pass" style="cursor: pointer;">¿No recuerdas tu contraseña?</span>
									<span style="color: green; display: none;" id="success-request-pass">Se ha enviado un enlace a tu correo.</span>
								</div>
							</div>
						</form>
					</div>
				
				</div>
			</div>
		</div>
	  </div>
	</div>