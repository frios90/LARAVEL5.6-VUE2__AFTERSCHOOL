<div id="overviews" class="section wb section-bg-1">
        <div class="container ">
            <div class="section-title row text-center">
                <div class="col-md-8 offset-md-2 fadeIn">
                    <p class="lead ">
						Los talleres son realizados por nuestros especialistas por medio de zoom,
						considernado el perfil único e irrepetible de cada potencial aprendiz.		
					</p>
                </div>
            </div>
            <hr class="invis"> 
            <div class="row"> 
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="course-item">
						<div class="contenedor-curso">
							<img src="images/curso-glifing.jpg" alt="" class="img-fluid imagen">
						</div>
						<div class="course-br">
							<div class="course-title">
								<h2><a href="#" title="">GLIFING</a></h2>
							</div>
							<div class="course-desc">
								<p>
									Evaluación y Entrenamiento de habilidades lectoras
								</p>
							</div>
							<div class="course-rating">
								5
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>								
							</div>
						</div>
						<div class="course-meta-bot">
							<ul>
								
							</ul>
						</div>
					</div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="course-item">
						<div class="contenedor-curso">
							<img src="images/curso-ingles.jpg" alt="" class="img-fluid imagen">
						</div>
						<div class="course-br">
							<div class="course-title">
								<h2><a href="#" title="">EASY ENGLISH</a></h2>
							</div>
							<div class="blog-desc">
								<p>
									Juego y actividades para integrar y fortalecer el uso de la lengua inglesa.
								</p>
							</div>
							<div class="course-rating">
								5
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>								
							</div>
						</div>
						<div class="course-meta-bot">
							<ul>
								
							</ul>
						</div>
					</div>
                </div>				
            </div>
			<hr class="invis"> 
			<div class="row">    
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="course-item">
						<div class="contenedor-curso">
							<img src="images/flores.jpg" alt="" class="img-fluid imagen">
						</div>
						<div class="course-br">
							<div class="course-title">
								<h2><a href="#" title="">EMPATHY</a></h2>
							</div>
							<div class="blog-desc">
								<p>
									Flores y emociones, para conocerme y conocer a otros.
								</p>
							</div>
							<div class="course-rating">
								5
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>	
								<i class="fa fa-star"></i>								
							</div>
						</div>
						<div class="course-meta-bot">
							<ul>
								
							</ul>
						</div>
					</div>
                </div>
				<div class="col-lg-6 col-md-6 col-12">
                    <div class="course-item">
						<div class="contenedor-curso contenedor-curso">
							<img src="images/clases-comunicación.jpg" alt="" class="img-fluid imagen">
						</div>
						<div class="course-br">
							<div class="course-title">
								<h2><a href="#" title="">COMUNICACIÓN</a></h2>
							</div>
							<div class="course-desc">
								<p>
									Afectividad para la efectividad en las comunicaciones.
								</p>
							</div>
							<div class="course-rating">
								5
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>
						</div>
						<div class="course-meta-bot">
							<ul>
								
							</ul>
						</div>
					</div>
                </div>
            </div>	
            <hr class="invis">
			<div class="row align-items-center ">
				<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12  ">
					<div class="message-box">
						<p style="text-align: justify">
							Los talleres son realizados por nuestros especialistas por medio de zoom,
							considerando el perfil único e irrepetible de cada potencial aprendiz.
						</p>
					</div>
				</div>
				<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
					<div class="post-media wow fadeIn contenedor-curso">
						<img src="images/img-video-conf.jpg" alt="" class="imagen img-fluid img-rounded img-talleres-after">
					</div>
				</div>
			</div>
			<div class="row align-items-center">
				<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
					<div class="post-media wow fadeIn contenedor-curso">
						<img src="images/img-class-2.jpg" alt="" class="imagen img-fluid img-rounded img-talleres-after">
					</div>
				</div>
				<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
					<div class="message-box">
						<p style="text-align: justify">
							Cada potencial aprendiz, accede a los talleres de acuerdo a su perfil,
							características y gustos.
						</p>
					</div>
				</div>
			</div>
        </div>
    </div>