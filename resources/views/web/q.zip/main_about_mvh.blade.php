<div class="hmv-box">
    <div class="container">
        <!-- end title -->
        <div class="row">
            <div class="col-lg-8 col-md-8 col-12">
                <div class="inner-hmv">
                    <div class="icon-box-hmv"><i class="flaticon-achievement"></i></div>
                    <h3>Misión</h3>
                    <div class="tr-pa">M</div>
                    <p style="text-align: justify">
                        <b>¡JUGAR!</b><br>  
                        Virtual After School es un espacio virtual que nació con la necesidad de potenciar los espacios vacíos que poseen los niños en su cotidiano. Hace mucho tiempo estuvo la idea en mente de sus creadores quienes, basándose en su experiencia, realizaron un profundo análisis sobre este habitual problema: Por años, la disponibilidad de tiempo de cada familia y los recursos en los horarios extraescolares para cuidar y potencial el bienestar de sus hijos e hijas generan frustraciones para sus integrantes en diversas formas y diferentes niveles. Luego de indagar en diferentes posibilidades y metodologías, llegamos a la conclusión de compartir en forma virtual un espacio tremendamente enriquecedor y proactivo, evidenciando que los mejores aprendizajes nacen de la mano de una relación de convivencia sana y transparente entre sus integrantes. Hoy, Virtual After School ya cuenta con experimentados profesionales, quienes aportarán fortalezas y habilidades en forma transparente, efectiva y afectiva.

                    </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <div class="inner-hmv">
                    <div class="icon-box-hmv"><i class="flaticon-eye"></i></div>
                    <h3>Vision</h3>
                    <div class="tr-pa">V</div>
                    <p style="text-align: justify">
                    
                        En  <b>VirtAf</b> entendemos que no existe, actualmente, un espacio igual al nuestro,
                        ya que atendemos la necesidad ancestral de tener un lugar seguro y enriquecedor 
                        para nuestros hijos e hijas fuera del horario escolar, en forma profesional, transparente, lúdica, segura y virtual.
                        Nuestro interés es seguir creciendo y fortaleciendo conocimientos y aprendizaje,
                        en forma siempre personalizada y divertida, sumando tanto a profesionales como a potenciales aprendices a nuestra comunidad.
                    
                    </p>
                </div>
            </div>            
        </div>
    </div>
</div>
