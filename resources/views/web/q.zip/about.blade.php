
<div id="overviews" class="section lb section-bg-1">
    <div class="container">  
        <div class="section-title row text-center">
            <div class="col-md-8 offset-md-2 fadeIn">
                <p class="lead p-about-title">
                    VirtAf ofrece una significativa cobertura al aprendizaje, por medio de espacios virtuales personalizados y profesionales expertos. 
                </p>
            </div>
        </div>      
        <div class="row align-items-center">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="">
                    <p>
                        <span class="span-about-title">Glifing:</span><br>
                        <span class="span-about-description">
                            Evaluación y entrenamiento psicopedagógico
                            ( ¡<b>Jugando en Línea</b>!  )
                        </span>          
                    </p>
                    <p style="text-align: justify">
                        <span class="span-about-title">Talleres:</span> <br>
                        <span class="span-about-description">
                            Espacios virtuales  de aprendizaje lúdico,
                            proporcionado por profesionales de la educación
                            ( ¡<b>y la Diversión</b>! )
                        </span>   
                        
                    </p>
                 
                </div>
                
            </div>				
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="post-media wow fadeIn contenedor">
                    <img src="images/a10.jpg" alt="" class="img-fluid img-rounded imagen">
                </div>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="post-media wow fadeIn contenedor">
                    <img src="images/a5.jpg" alt="" class="img-fluid img-rounded imagen">
                </div>
            </div>
            
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="message-box">
                    <p style="text-align: justify">
                        <span class="span-about-title">Informes de especialistas:</span><br>
                        <span class="span-about-description">
                            <b>Sin costos</b> adicionales
                        </span>  
                        
                    </p>
                    
                    <p style="text-align: justify">
                        <span class="span-about-title">Apoyo psicopedagógico S.O.S:</span><br>  
                        <span class="span-about-description">
                            ¡ <b>Profesionales</b>  en el momento y la <b>Hora Justa</b> !   
                        </span>                        
                        
                    </p>
                </div>
            </div>				
        </div>
        
    </div>
</div>