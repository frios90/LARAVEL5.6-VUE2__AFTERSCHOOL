<div class="all-title-box">
    <div class="container text-center">
        <h1>Talleres<span class="m_1"></span></h1>
    </div>
</div>