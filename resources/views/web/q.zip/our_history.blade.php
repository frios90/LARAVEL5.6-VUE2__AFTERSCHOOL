<section class="section lb page-section section-bg-1">
    <div class="container">
        <div class="section-title row text-center">
            <div class="col-md-12">
                <p class="lead" style="text-align: justify">
                    Virtual After School es un espacio virtual que nació ya hace mucho tiempo en
                    la mente de sus creadores, quienes, basándose en su experiencia, realizaron
                    un profundo análisis sobre un problema muy habitual: por años, los recursos
                    y disponibilidad de tiempo de cada familia en los horarios extra escolares
                    para cuidar y potencial el bienestar de sus hijos e hijas, generan 
                    frustraciones para sus integrantes, en diversas formas y diferentes 
                    niveles e profundidad.
                    Luego de buscar diferentes posibilidades y metodologías, tomamos la decisión de compartir en forma virtual, creando un espacio tremendamente enriquecedor y proactivo, evidenciando que los mejores aprendizajes nacen de la mano de una relación de convivencia sana y transparente entre sus integrantes.
                    Hoy, Virtual After School, ya cuenta con experimentados profesionales, quienes facilitan e reconocimiento de fortalezas y habilidades de cada integrante en forma transparente, efectiva y, por supuesto, afectiva.
                </p>
            </div>
        </div>
        <div class="section-title row text-center">
            <div class="col-md-12">
                <h3 class="title-custom-1">¿Como puedo ingresar a Virtual After School?</h3>
            </div>
        </div>
        <div class="timeline">
            <div class="timeline__wrap">
                <div class="timeline__items">
                    <div class="timeline__item">
                        <div class="timeline__content img-bg-01">
                            <h2>Paso 1</h2>
                            <p>Contactanos</p>
                        </div>
                    </div>
                    <div class="timeline__item">
                        <div class="timeline__content img-bg-02">
                            <h2>Paso 2</h2>
                            <p>
                                Alguien te llamara para coordinar la fecha y la hora.
                            </p>
                        </div>
                    </div>
                    <div class="timeline__item">
                        <div class="timeline__content img-bg-03">
                            <h2>Paso 3</h2>
                            <p>Podras solicitar evaluación, entrenamiento o talleres</p>
                        </div>
                    </div>
                    <div class="timeline__item">
                        <div class="timeline__content img-bg-04">
                            <h2>Paso 4</h2>
                            <p>
                                Realiza la evaluación haciendo Click en el enlace de la respuesta a tu confirmación de pago.
                            </p>
                        </div>
                    </div>
                    <div class="timeline__item">
                        <div class="timeline__content img-bg-01">
                            <h2>Paso 5</h2>
                            <p>
                                Recibirás un Informe Psicopedagógico completo y detallado
                            </p>
                        </div>
                    </div>
                    <div class="timeline__item">
                        <div class="timeline__content img-bg-02">
                            <h2>Paso 6</h2>
                            <p>
                                Ingresa con tu Usuario y Contraseña (lo recibirás junto al informe psicopedagógico)
                            </p>
                        </div>
                    </div>
                    <div class="timeline__item">
                        <div class="timeline__content img-bg-03">
                            <h2>Paso 7</h2>
                            <p>
                                Disfruta de las actividades y talleres disponibles en tu perfil de virtaf!
                            </p>
                        </div>
                    </div>   
                    <div class="timeline__item">
                        <div class="timeline__content img-bg-03">
                            <h2>Paso 8</h2>
                            <p>
                                <a style="color:#ffae00!important;" href="#footer" class="">!Hazlo ya¡</a>
                            </p>
                        </div>
                    </div>                    
                </div>
            </div>
        </div>
    </div>
</section>